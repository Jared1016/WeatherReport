//
//  weatherChangesModel.m
//  weatherReport
//
//  Created by lanou3g on 16/3/2.
//  Copyright © 2016年 刘斌. All rights reserved.
//

#import "WeatherChangesModel.h"

@implementation WeatherChangesModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}


@end
