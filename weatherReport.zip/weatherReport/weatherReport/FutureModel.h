//
//  FutureModel.h
//  weatherReport
//
//  Created by lanou3g on 16/3/3.
//  Copyright © 2016年 刘斌. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FutureModel : UIView

@property(nonatomic,strong)UILabel *labelWeak;
@property(nonatomic,strong)UILabel *labelTemperature;
@property(nonatomic,strong)UIImageView *imageWeather;



@end
