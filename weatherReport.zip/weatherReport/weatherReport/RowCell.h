//
//  RowCell.h
//  weatherReport
//
//  Created by lanou3g on 16/3/3.
//  Copyright © 2016年 刘斌. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RowCell : NSObject
@property (nonatomic, strong) NSString *interval;
@property (nonatomic, strong) NSString *setUpTime;
@end
