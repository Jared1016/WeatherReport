//
//  SecrollerView.h
//  weatherReport
//
//  Created by lanou3g on 16/3/3.
//  Copyright © 2016年 刘斌. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScrollViewModel : UIView

@property(nonatomic,strong)UILabel *labelData;
@property(nonatomic,strong)UILabel *labelName;





@end
