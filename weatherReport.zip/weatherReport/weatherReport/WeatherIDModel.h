//
//  WeatherID.h
//  weatherReport
//
//  Created by lanou3g on 16/3/1.
//  Copyright © 2016年 刘斌. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WeatherIDModel : NSObject

@property(nonatomic,strong)NSString *fa;
@property(nonatomic,strong)NSString *fb;


@end
