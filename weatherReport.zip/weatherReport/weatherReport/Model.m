//
//  Model.m
//  weatherReport
//
//  Created by lanou3g on 16/2/29.
//  Copyright © 2016年 刘斌. All rights reserved.
//

#import "Model.h"

@implementation Model


- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}






@end
