//
//  LWNoticeViewController.h
//  weatherReport
//
//  Created by lanou3g on 16/3/2.
//  Copyright © 2016年 刘斌. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LWNoticeViewController : UIViewController
@property (nonatomic, strong) NSString *date;
@end
