//
//  LWLeftEnumTableViewCell.h
//  weatherReport
//
//  Created by lanou3g on 16/2/29.
//  Copyright © 2016年 刘斌. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LWLeftEnumTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *LwLeftEnumCellImageView;
@property (weak, nonatomic) IBOutlet UILabel *LwLeftEnumCellLable;

@end
