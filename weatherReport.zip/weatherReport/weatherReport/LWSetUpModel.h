//
//  LWSetUpModel.h
//  weatherReport
//
//  Created by lanou3g on 16/3/7.
//  Copyright © 2016年 刘斌. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LWSetUpModel : NSObject
@property (nonatomic, copy) NSString *noticeTime;
@end
