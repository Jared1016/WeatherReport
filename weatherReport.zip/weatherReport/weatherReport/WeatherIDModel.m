//
//  WeatherID.m
//  weatherReport
//
//  Created by lanou3g on 16/3/1.
//  Copyright © 2016年 刘斌. All rights reserved.
//

#import "WeatherIDModel.h"

@implementation WeatherIDModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}


@end
